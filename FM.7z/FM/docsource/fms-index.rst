.. FMS documentation master file, created by
   sphinx-quickstart on Wed Jan  1 09:50:27 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to FMS's documentation!
===============================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   ../README
   APIDoc/modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
