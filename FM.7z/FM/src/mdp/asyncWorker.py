import sys
import time
from pprint import pprint
import asyncio
import zmq
import aiozmq
from logger.logMsg import *
from utils import pyutil as utl
from multipledispatch import dispatch

from util import split_address

###
PROTO = 'FMW'
VERSION = '01'


class ConnectionNotReadyError(RuntimeError):
    """Exception raised when attempting to use the MDPWorker before the handshake took place.
    """
    pass
#

class MissingHeartbeat(UserWarning):
    """Exception raised when a heartbeat was not received on time.
    """
    pass
#
###
async def repeat(interval, func, *args, **kwargs):
    """Run func every interval seconds.

    If func has not finished before *interval*, will run again
    immediately when the previous iteration finished.

    * args and ** kwargs are passed as the arguments to func.
    """
    while True:
        await asyncio.gather(
            func(*args, **kwargs),
            asyncio.sleep(interval),
        )




class AsyncWorker(object):
    
    HB_LIVENESS = 3
    HB_INTERVAL = 2
    
    def __init__ (self,endpoint):
        self.endpoint = endpoint
        self.service = utl.ProcessName()
        self.queue = asyncio.Queue()
        self.proto_version = PROTO + '-' + VERSION
        self.proto_service = self.proto_version + '-' + self.service
        utl.ProcessType(PROTO)
    
    # should it be a property
    def setSock(self,sock):
        self.sock = sock
    
    async def send_hb(self):
        hb_msg = utl.toBytes([ b'', self.proto_version, b'\x04' ])
        #LogAudit(f"IN Send_HB {hb_msg}")
        self.sock.write(hb_msg)
        
    async def send_ready(self):
        ready_msg = [ b'', self.proto_version, b'\x01', self.proto_service ] # can it be just self.service.
        to_send = utl.toBytes(ready_msg)
        print("_send_ready with ",to_send)
        
        self.sock.write(to_send)
        #self.curr_liveness = self.HB_LIVENESS
        return
    
    async def handle_msg(self,msg_type,msg):
        """
        TODO: Refactor changes 
        """
        #print(f"handle_msg {msg} and msgtype {msg_type}")
        if msg_type == b'\x05':
            #Output reply from subworker forward it to Processrequest for consolidation
            if msg[-1:] == [b'SEND_MORE']:
                msg = msg[:-1]
                msg = {'Output' : utl.s2m(utl.toStr(msg)), 'SendMore' : True}
            else:
                msg = {'Output' : utl.s2m(utl.toStr(msg)), 'SendMore' : False}
            await self.on_request(utl.toBytes(msg))
            return
        if msg_type != b'\x02':
            # do nothing.. should disconnect and reconnect
            self.curr_liveness = 0
            return
        
        envelope, msg = split_address(msg)
        envelope.append(b'')
        envelope = [ b'', self.proto_version, b'\x03'] + envelope # REPLY
        self.envelope = envelope
        if msg_type == b'\x02':
            await self.on_request(msg) # do some work / its a multidispatch on msg_type
        return

    async def on_message(self): # To be in ioloop
        """
        TODO: Refactor changes done for FTQS
        """
        while True:
            #print(f"on_message")
            fullmsg = await self.sock.read()
            #print(f" on_message with msg = {fullmsg}")
            _,proto,msg_type,*msg = fullmsg

            #IF it is another worker reply then forward it to the actual client of this worker else handle the message as it is
            if utl.toStr(proto)[:3] == 'FMC' :
                print("GOT REPLY FROM SUB WORKER!!!!!!!!!!!!!!!!!!")
                msg_type=  b'\x05'
            
            # do version and msg format checks
            await self.handle_msg(msg_type,msg)
        
        print('end on_message')
    
    async def reply(self,msg,more=False):
        """
        TODO: Refactor changes done for FTQS
        """
        print(100*'*')
        #print("ASYNC WORKER REPLY MSG" , msg)
        print("ENVELOPE : ", self.envelope)

        #Check if it is a subworker task from ProcessRequest as client or not . if true then no need to add envelop seperately
        #sometimes msgs comes with list with < 2 length
        if len(msg) > 2:
            _,proto,*l = msg
        else:
            proto = 'FMW'
        print(utl.toStr(proto[:3]))

        print(100*'*')
        to_send = None
        serviceinfo = False
        if utl.toStr(proto)[:3]!= 'FMC' :
            # prepare full message
            more_expected = more
            #print(f"envelop {self.envelop}")
            to_send = self.envelope[:]  # copy the list and not just refernece it
            #print(f"first to_send {to_send}")
            if isinstance(msg, list):
                to_send.extend(msg)
                more_expected = more or msg[-1:] == [b'SEND_MORE']
            else:
                to_send.append(msg)
            #print(f"second to_send {to_send}")
            if not more_expected : # envolop not needed as worker should be ready for new client
                self.envelope = None
            else :
                if msg[-1:] != [b'SEND_MORE'] : to_send.append(b'SEND_MORE')

        else:
                to_send = msg[:]
        
        
        to_send = utl.toBytes(to_send)
        #print(f"Reply to be sent to client {to_send}")
        self.sock.write(to_send) # should send async across network
    
   
    async def on_request(self,msg):
        msg='on_request -> Should be Overridden'
        assert 0,msg
    

async def sockStream(worker):
    sock = await aiozmq.create_zmq_stream(zmq.DEALER,connect=worker.endpoint)
    return sock

async def StartLoop(worker):
    loop = asyncio.get_event_loop()
    
    sock = await sockStream(worker)
    worker.setSock(sock)
    await worker.send_ready() # register first with broker
    
    task1 = loop.create_task(repeat(worker.HB_INTERVAL,worker.send_hb)) # heartbeat loop
    task2 = loop.create_task(worker.on_message()) # recieve loop
    
    await task1
    await task2

