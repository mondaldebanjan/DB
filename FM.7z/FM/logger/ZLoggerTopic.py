#-----------------------
# This file is to publish logs to a given port of zmq 
# Class : ZLogger takes port,sourcefilename,logging level for its initiation
#       This class has attributes : port,filename,level,zmqH(handler) 
#       Funtions:
#      def getZLogHandler <--  This is exposed so that other can use the habdler to add into their own logger
#      def getZLogger     <--  This is exposed so that other can use the logger directly
#      def ZLogInfo,ZLogWarning,ZLogAudit ... <-- Takes a msg string as argument, These can be used directly to log a message
#------------------------

import time
import logging
import zmq,os
from zmq.log import handlers as zmqHandler
import sys

getframe_expr = 'sys._getframe({}).f_code.co_name'

logging.AUDIT = 32  # positive yet important
logging.addLevelName(logging.AUDIT, 'AUDIT')      # new level NOTE:This is a custom level

class ZLoggerTopic:
    def __init__(self, loggingEndpoint,server, filename, level):
        self.loggingEndpoint = loggingEndpoint
        self.filename=filename
        self.level = level
        self.server = server
        #creating zmq Socket
        context = zmq.Context()
        sender = context.socket(zmq.PUSH)
        sender.connect(loggingEndpoint)

        #Setting the ZMQ Socket ss handler,
        #By default PyLogger uses PUB-SUB we are using PUSH-PULL pls refer
        #https://github.com/zeromq/pyzmq/blob/master/zmq/log/handlers.py
        self.zmqH=zmqHandler.PUBHandler(sender)

        #A handler which only does publish to an endpoint
        self.publishport = "22222"
        log_sock = context.socket(zmq.PUB)
        log_sock.connect("tcp://127.0.0.1:"+self.publishport)
        self.pubH=zmqHandler.PUBHandler(log_sock)

        #Format as:    09/20/19 05:32:17 *  1118 * AUDIT * ftadm        * Log file opened.  Continuation o
        #We can format from an external file also at later versions
        self.zmqH.formatters = {
			logging.DEBUG:logging.Formatter("   %(asctime)s *  %(process)s * %(levelname)s * logger   * %(message)s",datefmt='%m/%d/%Y %I:%M:%S %p'),
			logging.INFO:logging.Formatter("   %(asctime)s * {} * %(name)s  *  %(process)s * %(levelname)s * logger  * %(message)s".format(self.filename),datefmt='%m/%d/%Y %I:%M:%S %p'),
			logging.WARN:logging.Formatter("   %(asctime)s *  %(process)s * %(levelname)s * logger  * %(message)s",datefmt='%m/%d/%Y %I:%M:%S %p'),
			logging.ERROR:logging.Formatter("   %(asctime)s *  %(process)s * %(levelname)s * logger  * %(message)s",datefmt='%m/%d/%Y %I:%M:%S %p'),
			logging.CRITICAL:logging.Formatter("   %(asctime)s *  %(process)s * %(levelname)s * logger  * %(message)s",datefmt='%m/%d/%Y %I:%M:%S %p'),
                        logging.AUDIT:logging.Formatter("   %(asctime)s * {} * %(name)s  *  %(process)s * %(levelname)s * %(message)s".format(self.filename),datefmt='%m/%d/%Y %I:%M:%S %p')}
        self.pubH.formatters = self.zmqH.formatters


    def getZLogHandler(self):
        #Utility
        #Return the overriden PUSH-PULL Handler induced logger 
        return self.zmqH

    def getZLogger(self):
        #Utility 
        #Create the logger
        #getting the caller who is trying to log something
        caller = eval(getframe_expr.format(4))

        #Setting Level and the logging initiation point or calling module
        logger = logging.getLogger(caller)

        logger.setLevel(self.level)

        #adding the PUSH Handler to logger
        logger.addHandler(self.zmqH)

        loggerPub = logging.getLogger(caller+"Pub")
        loggerPub.setLevel(self.level)
        loggerPub.addHandler(self.pubH)
        logger.propagate = False
        loggerPub.propagate = False
        return logger,loggerPub

    def ZLogInfo(self,logStr,filter=None):
        #getting the caller
        logger,loggerPub = self.getZLogger()
        subtopic=str(os.getpid())+self.server
        #logging the message
        msg = zmq.log.handlers.TOPIC_DELIM.join([subtopic, logStr]) 
        #logging the message
        logger.info(msg)
        loggerPub.info(logStr)

    def ZLogDebug(self,logStr,filter=None):
        #getting the caller
        logger,loggerPub = self.getZLogger()

        #logging the message
        logger.debug(logStr)
        loggerPub.debug(logStr)

    def ZLogWarning(self,logStr,filter=None):
        #getting the caller
        logger,loggerPub = self.getZLogger()
        subtopic=str(os.getpid())
        #logging the message
        msg = zmq.log.handlers.TOPIC_DELIM.join([subtopic, logStr])
        logger.warn(msg);
        loggerPub.warn(logStr)

    def ZLogError(self,logStr,filter=None):
        #getting the caller
        logger,loggerPub = self.getZLogger()
        subtopic=str(os.getpid())
        #logging the message
        msg = zmq.log.handlers.TOPIC_DELIM.join([subtopic, logStr])
        logger.error(msg);
        loggerPub.error(logStr)

    def ZLogAudit(self,logStr,filter=None):
        #getting the caller
        logger,loggerPub = self.getZLogger()
        logger.audit = lambda msg, *args: logger._log(logging.AUDIT, msg, args)
        loggerPub.audit = lambda msg, *args: loggerPub._log(logging.AUDIT, msg, args)
        #logging the message
        subtopic=str(os.getpid())+self.server
        msg = zmq.log.handlers.TOPIC_DELIM.join([subtopic, logStr])
        logger.audit(msg)
        loggerPub.audit(logStr)
