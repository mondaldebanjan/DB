# -*- coding: utf-8 -*-
"""
Created on Tue Oct  8 12:48:20 2019

@author: Shyam_Srinivasan
"""
from custom.includes import *
from custom.customRegisters import *
import custom.customcalc as cc

import cx_Oracle

@method(PreRequest,'Client-1')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.ctime())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    #defaultQ = ['select a.deal_type,a.deal_num ,b.deal_num,b.deal_type from all_deals a,all_deals b,all_deals c where 1=1']
    defaultQ = ['select * from gl_trans_all_test']
    #defaultQ = ['select count(*) from gl_trans_all_test']
    #defaultQ = ['select * from gl_trans_all_test where rownum <=11000']
    #defaultQ = ['select * from gl_trans_all_test where rownum <=2']
    customQ = [] #cc.GetEIRQuery()

    yield {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-TestService'}


@method(PostReply,'Client-1')
def PostReply(ReplyMsg):
    ## Delete debugs afterwards
    print('TIME POST-REPLY',time.ctime())
    #print(ReplyMsg)
    output = getVal(ReplyMsg,['DATA','Output','Data'],None)
    #print(output)
    llist=[v for k,v in output[0].items()] if output else []
    print('THE Reply i got is  :num of records ' , len(llist[0]))
    #cc.processAmort(output)
    yield ReplyMsg

@method(PreRequest,'TestClient')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.time())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    ReqMsg.pop('ProcessName', None)
    #return ReqMsg
    defaultQ= ['select to_char(sysdate) sys_date from dual','select (2+3) from dual']
    customQ = [] #cc.GetUC()
    return {"Query": customQ if len(customQ) else defaultQ 
            ,"Service": 'FMW-01-TestService'}


@method(PostReply,'TestClient')
def PostReply(ReplyMsg):
    ## Delete debugs afterwards
    print('TIME POST-REPLY',time.time())
    print(list(ReplyMsg))
    output = getVal(ReplyMsg,'OUTPUT',None)
    llist=[v for k,v in output.items()] if output else [] 
    print('THE Reply i got is ',llist,' :num of records ' , len(llist))
    return ReplyMsg

@method(PreRequest,'ClientGL')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.ctime())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    defaultQ= ['select JNLREF,ACCNUM from GL_TRANS_ALL']
    customQ = cc.GetGLToTUTQuery()
 
    return {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-GLService1'}


@method(PostReply,'ClientGL')
def PostReply(ReplyMsg):
    ## Delete debugs afterwards
    print('TIME POST-REPLY',time.ctime())
    output = getVal(ReplyMsg,'OUTPUT',None)
    llist=[v for k,v in output['Data'].items()] if output else []
    #print('THE Reply i got is ',llist[0],' :num of records ' , len(llist[0]))
    print('THE Reply i got is num of records ' , len(llist[0]))
    return ReplyMsg

@method(PreRequest,'ClientRate')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.time())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    defaultQ= ['GIVE USD/INR RATE']
    customQ = []
    return {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-RateService'}


@method(PostReply,'ClientRate')
def PostReply(ReplyMsg):
    print('TIME POST-REPLY',time.time())
    output = getVal(ReplyMsg,'OUTPUT',None)
    llist=[v for k,v in output['Data'].items()] if output else []
    print('THE Reply i got is ',llist[0],' :num of records ' , len(llist[0]))
    return ReplyMsg


@method(PreRequest,'GLTestFTQS')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.ctime())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    defaultQ= ['select JNLREF,ACCNUM from GL_TRANS_ALL']
    customQ = cc.GetSampleFTQSQuery()
    print("Custom QUery is :", customQ)
    return {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-FTQS'}

@method(PostReply,'GLTestFTQS')
def PostReply(ReplyMsg):
    print('TIME POST-REPLY',time.ctime())
    print(200*'*')
    print(ReplyMsg)
    return ReplyMsg


@method(PreRequest,'GetSystemDateClient')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.time())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    defaultQ= ["select TO_char(get_system_date) getsysdate from dual"]
    customQ = [] #cc.GetEIRQuery()
    return {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-GetSystemDateService'}


@method(PostReply,'GetSystemDateClient')
def PostReply(ReplyMsg):
    ## Delete debugs afterwards
    print('TIME POST-REPLY',time.time())
    print(list(ReplyMsg))
    output = getVal(ReplyMsg,'OUTPUT',None)
    llist=[v for k,v in output.items()] if output else []
    print('THE Reply i got is ',llist,' :num of records' , len(llist))
    return ReplyMsg

@method(PreRequest,'NostroClient')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.time())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    defaultQ= []
    customQ = cc.GetNostroQuery()
    return {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-NostroServiceNoBind'}


@method(PostReply,'NostroClient')
def PostReply(ReplyMsg):
    ## Delete debugs afterwards
    print('TIME POST-REPLY',time.time())
    print(list(ReplyMsg))
    output = getVal(ReplyMsg,'OUTPUT',None)
    llist=[v for k,v in output.items()] if output else []
    #print('THE Reply i got is ',llist,' :num of records ' , len(llist))
    print('THE Reply i got is ', llist[0]['0'][0])
    connection = cx_Oracle.connect("d1191/z@10.66.118.213:1521/ft12cdb")

    # Obtain a cursor
    cursor = connection.cursor()
 
    custom_dictionary = llist[0]['0'][0]

    cols  = ','.join( list(custom_dictionary.keys() ))
    params= ','.join( ':' + str(k) for k in list(custom_dictionary.keys()))
    statement = 'insert into nostro_balances(' + cols +' ) values (' + params + ')'
    print(statement)
    cursor.execute(statement,custom_dictionary)

    cursor.close()
    connection.commit()
    connection.close()

    return ReplyMsg




@method(PreRequest,'HTTPClient')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.time())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    defaultQ= ['RUN The HTTP Server']
    customQ = [] #cc.GetEIRQuery()
    return {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-TestService'}


@method(PostReply,'HTTPClient')
def PostReply(ReplyMsg):
    ## Delete debugs afterwards
    print('TIME POST-REPLY',time.time())
    print('THE Reply i got is ', ReplyMsg)
    return ReplyMsg
