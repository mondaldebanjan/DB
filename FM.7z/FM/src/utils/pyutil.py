import json
import os
from utils import defaults 
import functools
import operator
import numpy as np
from datetime import datetime as dt
from multipledispatch import dispatch
from logger.logMsg import *
import argparse,importlib

#dispatching based on dictionary
def multi(dispatch_fn):
    def _inner(*args, **kwargs):
        return _inner.__multi__.get( dispatch_fn(*args, **kwargs), _inner.__multi_default__)(*args, **kwargs)
    _inner.__multi__ = {}
    _inner.__multi_default__ = lambda *args, **kwargs: None  # Default default
    return _inner


# dispatch key is the value based on which the dispatch works. It needs to be be hashable.
def method(dispatch_fn, dispatch_key=None):
    def apply_decorator(fn):
        if dispatch_key is None:
            # Default case
            dispatch_fn.__multi_default__ = fn
        else:
            dispatch_fn.__multi__[dispatch_key] = fn
        return dispatch_fn

    return apply_decorator


# async dispatching based on dictionary
def async_multi(dispatch_fn):
    async def _inner(*args, **kwargs):
        key = await dispatch_fn(*args, **kwargs)
        ret = await _inner.__multi__.get( key, _inner.__multi_default__)(*args, **kwargs)
        return ret
    _inner.__multi__ = {}
    
    async def default(*args,**kwargs):
        return None
    _inner.__multi_default__ = default  # Default default
    
    return _inner


# async dispatch key is the value based on which the dispatch works. It needs to be be hashable.
def async_method(dispatch_fn, dispatch_key=None):
    def apply_decorator(fn):
        if dispatch_key is None:
            # Default case
            dispatch_fn.__multi_default__ = fn
        else:
            dispatch_fn.__multi__[dispatch_key] = fn
        return dispatch_fn

    return apply_decorator 

def compose(*funcs):
    """Return a new function s.t.
    compose(f,g,...)(x) == f(g(...(x)))"""
    def inner(data, funcs=funcs):
        result = data
        for f in reversed(funcs):
            result = f(result)
        return result
    return inner

def interleave(l,sep):
    ''' Give a list and a seperator list or string, it interleaves the s between the l's and returns a list'''
    n = len(l)
    s = sep  if isinstance(sep,list) else [sep]*n   

    ret = [*sum(zip(l,s),())]
    return ret


def memoize(f):
    ''' TODO: implement lru_cache from functools with deep copy option'''
    cache = {}
    @functools.wraps(f)
    def helper(x='__NONE__'):
        ret = cache[x] if cache.get(x,None) else f(x)
        cache[x] = ret
        return ret
    return helper


def smemoize(f):
    ''' 
    .. TODO::
       Static memoize. Implement with lru_cache 
    '''

    cache = {}
    @functools.wraps(f)
    def helper(x=None):
        if cache.get('__NONE__',None):
            pass
        else:
            cache['__NONE__']=f(x)
            
        return cache['__NONE__']
    return helper

@memoize
def env(key):
    '''Get value of key from env file'''
    return Config().get(key)

@memoize
def envfile(x):
    ''' Get From sys env FM_CONFIG_FILE
    FM_CONFIG_FILE is expected to point to the json file having config'''
    
    f = x if x else getSysEnv('FM_CONFIG_FILE')
    with open (f,'r') as jsonfile:
        data = json.load(jsonfile)
        return data

@memoize
def getSysEnv(s):
    ''' Gets the given system varialbe defined.
    * If not found , get the default in the program.
    * If not found , return None
    * Cache the result'''
    
    return os.environ.get(s,defaults.envDefaults.get(s,None))
    
def Map2Json (dataMap):
    '''Converts dict to Json.Retain dates and other datatypes as string.

    .. note::

       Use toStr(dict) instead.
    '''
    assert isinstance(dataMap,dict),"Input is not a dict:-"
    return json.dumps(dataMap,default=str) # 

def s2b(s,encode='utf-8'):
    assert isinstance(s,str),"Input is not a string:-"
    return s.encode(encode)

def b2s(b,encode = 'utf-8'):
    assert isinstance(b,bytes),"Input is not a byte:-"
    return b.decode(encode)

def s2m(s):
    return json.loads(s)


m2j = Map2Json
m2b = compose(s2b,m2j)
b2m = compose(s2m,b2s)

@dispatch(bytes)
def _toStr(b):
    return b2s(b)

@dispatch (object)
def _toStr(default):
    return str(default)

@dispatch (dict)
def _toStr(m):
    return m2j(m)


@dispatch(list)
def _toStr(blist):
    '''Convert the list of bytes to one string'''
    ret  = functools.reduce(lambda a,b: operator.concat(_toStr(a),_toStr(b)), blist)
    ret = _toStr(ret)
    #print(f'_toStr - > {ret}')
    return ret

def toStr(input):
    '''
    Convert the input of bytes to string.
    Input could be a list of bytes/string , dict or bytes or an object with string representation

    :param input: input to be converted to a single string.
    :type input: list/dict/string/bytes  
    :return: returns a string
    :rtype: str
    '''
    return _toStr(input)



@dispatch(bytes)
def _toBytes(msg):
    return msg

@dispatch(list)
def _toBytes(msg):
    return [_toBytes(i) for i in msg] 

@dispatch(dict)
def _toBytes(msg):
    return m2b(msg) 

@dispatch(str)
def _toBytes(msg):
    return s2b(msg) 

@dispatch(object)
def _toBytes(msg):
    return _toBytes(str(msg))

def toBytes(input):
    '''
    Convert the input to bytes. Used to send the message over zmq.
    Input could be list/string/dict/bytes or object with string interface

    :param input: input to be converted to bytes
    :type input: str/dict/list/bytes
    :return: returns byte representation of input
    :rtype: bytes
    '''
    return _toBytes(input)

def FtLogFile(mapData):
    filepath = env('FTLogFile')
    filepath.format(d=mapData)
    return filepath

@memoize
def cmdEnv(t=None):
    '''TODO:Get cmd line params and get the envs from them using argparse'''
    #cmdDict = vars(ParseCmdLine())
    #print("cmdDict is : ", cmdDict)

    #getVal(cmdDict,t,{}) 
    return {}


def getConnStr():
    user = 'infy2'
    passwd = 'LMP789QR'
    connStr = user+'/'+passwd+'@'+'10.66.118.213:1523/ftdb'


    connStr = getVal(Config(""),'ConnStr')
    # call the function in the config
    #fun = getVal(Config(),'ConnStr')
    #if fun :
    #    connStr = None
        #assert 0 , 'TO DO , function to call C code for connstr'

    return connStr

connStr = None

@smemoize
def ProcessType(name = None):
    return name

@smemoize
def ProcessName(name = None):
    return name

def ProcessID():
    return os.getpid()

@memoize
def Ptype():
    ''' returns the type as defined in the config. Acts like static variable'''
    return getVal(Config(),'Type',None)

def TimeStamp():
    return dt.now()

def getVal(dictionary, keys, default=None):
    """
    Get the value if present for the given key(s) in the passed dict.
    The keys can be of the form ["key1","key2","key3"] or "key1.key2.key3"
    Returns None if key is not valid.
    """
    return functools.reduce(lambda d, key: d.get(key, default) if isinstance(d, dict) else default, 
                            keys.split(".") if isinstance(keys,str) else keys, 
                            dictionary)

###################################################  

def customInvocation(fun,msg):
    ''' Always expect a hash map in return '''
    if not isinstance(msg,dict):
        assert 0,"customInvocation expects a dictionary as an argument"
    args = {**msg,**{"ProcessName":ProcessName()}} # processname should be always current process processname
    #print(f"args for customInvocation :{args}")
    retMsg = fun(args)
    #if not isinstance(retMsg,dict):
    #    retMsg = {"ERROR": retMsg}
    #print(f'Yielding from customInvocatoin {retMsg}')
    return retMsg

def customInvocation1(fun,msg):
    '''
    Async invocation of the custom function supplied.
    Always expect a hash map in return 
    '''
    if not isinstance(msg,dict):
        assert 0,"customInvocation expects a dictionary as an argument"
    args = {**msg,**{"ProcessName":ProcessName()}} # processname should be always current process processname
    #print(f"args for customInvocation :{args}")
    for retMsg in  fun(args):
    #if not isinstance(retMsg,dict):
    #    retMsg = {"ERROR": retMsg}
        #print(f'Yielding from customInvocatoin {retMsg}')
        yield retMsg


def CallAssert(funName='NONE'):
    ''' Helper for calling assert for a function. Lambda assert is not allowed'''
    def helper():
        assert 0,funName + 'not assigned correct function'
    return helper


# can be accessed by clients to call sendAndRec in a loop
# should be initialized with correct function (with socket and msg) and can be called in a loop 
# valid only for Request->Response type connection: Synchronous
SendAndRec = CallAssert('SendAndRec')


@smemoize
def Config(t=None):
    return {**getVal(envfile(False),'FM',{}),\
            **getVal(envfile(False),t,{}),\
            **cmdEnv(t)}

def hooks():
    """
    Gets the custom hooks as defined under *HOOKS* in the env file.
    The dict is of the form 

    .. code-block:: python

       # showing part of env file..
       {"HOOKS" : { "Custom" : ["GLService", "FC1-NostroService", "FC2-NostroService"]}}

    Get the path for the processName and tries to load the package mentioned in the key.
    """

    hdict  = getVal(envfile(False),'HOOKS',{})
    hookpath = [k for k,v in hdict.items() if ProcessName() in v]
    hookpath.append("custom")
    try:
        path =  importlib.import_module(hookpath[0])
        print("MODULE FOUND!!") 
    except:
        print("MODULE NOT FOUND!!!!!!! ", hookpath[0])
        assert 0,f"MODULE NOT FOUND!!!!!!!{hookpath[0]}"
    return path

 
def FMInit(typestr):
    '''
    Initializes based on type.
    Takes the argv cmds , parses it and finds out the server name or client name.
    Takes the endpoint as given in the config file.
    Takes request socket type as given in the config file.'REQ' or 'DEALER'
    '''
    #ParseCmdLine()
    Config(typestr)# default type from cmdline


def npdt64_to_datetime(date):
    timestamp = ((date - np.datetime64('1970-01-01T00:00:00')) / np.timedelta64(1, 's')) 
    return dt.utcfromtimestamp(timestamp)

def chunk_it(l,chunk_size = 1000):
    ''' Get all the chunks of the data in a single list. This can be send as a reply message '''
    assert isinstance(l,str) or  not isinstance(l,bytes),f" input is {type(l)} : Expect either str or bytes"

    return [chunk for chunk in chunkList(l,chunk_size)]

def chunkList(l,chunk_size):
    ''' Generator function for Chunking the string before sending it to zmq port in frames'''
    #print(f" the input is l->{l}")
    for i in range(0,len(l),chunk_size):
        yield l[i:i+chunk_size]

def formReply(rows,chunk_size = 1000,more = False):
    """
    Called from workers where the reply is formed before sending to client.
    This is of the generic format::
                 
       {"Service": ProcessName ,
       "Output" : {"Data" : rows }
       }
        
    :param rows: list of dict 
    :param chunk_size: size of each frame of zmq reply. default 1000
    :param more: Indicates if the message is the end of reply or more is expected to be sent to client
    :type rows: list
    :type chunk_size: int
    :type more: boolean
     
    :returns: A list of chunked and formatted string.
    """
    replyMsg = {"Service":ProcessName(),"Output": {"Data" : rows}} 
    data = toStr(replyMsg)
    replyList = chunk_it(data,chunk_size)
    #print(f"more is {more}")
    if more :
        replyList.append(b'SEND_MORE')

    LogAudit(f" reply length is {len(replyList)} ")
    return replyList

def mergeDicts(m,n):
    """
    Merges two dictionaries. 
    The keys are not repeated but the values are appended to a list for same keys. No value is lost::
    
       {'a': 1, 'b': 2} + {'c':1,'b':4} -> {'a':1,'b':[2,4],'c':1}

       >>>mergeDicts({'a': 122 , 'b':{'y': [2,3]} ,'c': 'A string'},{'c':'A Number','b':{'x':[4,5,6]}})
       {'a': [122], 'c': ['A string', 'A Number'], 'b': {'x': [4, 5, 6], 'y': [2, 3]}}
       
    Works on recursive dictionaries.
    """
    return {k:join_dict_vals(m.get(k),n.get(k)) for k in m.keys() | n.keys() }


def join_dict_vals(mv,nv):
    if isinstance(mv,dict) and isinstance(nv,dict):
        return mergeDicts(mv,nv)
    
    def makelist(x):
       return x if isinstance(x,list) else [x]
    
    mv = makelist(mv) if mv != None else []
    nv = makelist(nv) if nv != None else []
    return mv + nv


@smemoize
def ParseCmdLine(VERSION = "v1.0.0 (2019-10-26)"):
    configDict = {}
    parser = argparse.ArgumentParser(prog='FM',description='*'*30,epilog="""Additional information:\n
             1.You can also write the command line arguments in a file\n
             2.Call startup.py @filename to run\n""",fromfile_prefix_chars='@')#if the optins is too long give the option from a file

    parser.add_argument("-v", "--version", action="version", version=VERSION)

    #give the whole config file
    parser.add_argument("--config", help='give a config file name to override the default fm.config',metavar='FILE_NAME')

    #Startup arguments----
    #Service FMC-BAML FMW-1-TestService <ClientName> <Worker-API-ServiceName>
    #Client
    parser.add_argument("-c","--client", help='starts up the client',nargs=1,metavar=('NAMEOFCLIENT'))

    #Worker
    parser.add_argument("-w","--worker", help='starts up the workers of given number',nargs='+',metavar=['SERVICENAME','NUMWORKER'])

    #Broker
    parser.add_argument("-b","--broker",action='store_true',help='starts up the broker process')

    #httpclient
    parser.add_argument("-hc","--httpclient",action='store_true',help='starts up the http client process')

    #ENDPOINT
    parser.add_argument("-e","--endpoint", help='provide the endpoint e.g: tcp://127.0.0.1:55555',nargs=1,metavar='ENDPOINT')

    parser.add_argument("--nolog", help='Do not sore log',action='store_true')

    args = parser.parse_args()

    if args.config is not None:
        with open(args.config) as json_data:
            try:
                data = json.load(json_data)
                args.config = data
            except json.JSONDecodeError:
                print('Invalid JSON format')
    return args
