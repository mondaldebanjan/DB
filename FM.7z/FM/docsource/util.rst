MDP util module
===============

.. automodule:: mdp.util
   :members:
   :member-order: bysource

