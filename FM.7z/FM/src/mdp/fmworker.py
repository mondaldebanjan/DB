"""
worker would initiate a worker based on the config and/or the 
command line arguement.
Connect to the MDP port in the MDP server.
Register with the service name that the worker is providing.
ServiceName : FC1-WQ  -- service on FC1 server/db and type WQ-Worker Query.
"""
import inspect
import os
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0,parentdir)

import zmq
from zmq.eventloop.ioloop import IOLoop
import utils.pyutil as utl
import custom.customScripts as custom
from logger.logMsg import *

from worker import MDPWorker

###

class FMWorker(MDPWorker):

    HB_INTERVAL = 10000
    HB_LIVENESS = 3

    count = 0

    def on_request(self, msg):
        self.count = self.count + 1
        print('MEssage on Request is : ' , msg)
        for reply in ProcessRequest(utl.b2m(msg[0])): # consider many msg frames from client. TODO
            self.reply(reply)


###

def ProcessRequest(msg):
    for ret in utl.customInvocation1(custom.ProcessRequest,msg):
        yield ret

if __name__ == '__main__':
    context = zmq.Context()
    utl.ProcessName('TestService') # should be same as last part of service name
    worker = FMWorker(context, "tcp://127.0.0.1:5555", b"FMW-01-TestService")
    IOLoop.instance().start()
    worker.shutdown()


### Local Variables:
### buffer-file-coding-system: utf-8
### mode: python
### End:
