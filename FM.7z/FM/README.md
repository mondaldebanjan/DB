MDP - the Majordomo Protocol
============================

An implementation in Python using pyzmq.

For the specification of see
<center>
<a href="http://rfc.zeromq.org/spec:7">MDP - the Majordomo Protocol<a/>
</center>



