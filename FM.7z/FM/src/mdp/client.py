# -*- coding: utf-8 -*-

import zmq
from zmq.eventloop.zmqstream import ZMQStream
from zmq.eventloop.ioloop import IOLoop, DelayedCallback
from utils import pyz 
from utils import pyutil as utl 
from logger.logMsg import *

###

PROTO_VERSION = 'FMC-01'

###

class InvalidStateError(RuntimeError):
    """Exception raised when the requested action is not available due to socket state.
    """
    pass
#

class RequestTimeout(UserWarning):
    """Exception raised when the request timed out.
    """
    pass
#
###

class MDPClient(object):

    """Class for the MDP client side.

    Thin asynchronous encapsulation of a zmq.REQ socket.
    Provides a :func:`request` method with optional timeout.

    Objects of this class are ment to be integrated into the
    asynchronous IOLoop of pyzmq.

    :param context:  the ZeroMQ context to create the socket in.
    :type context:   zmq.Context
    :param service:  the service the client should use
    :type service:   str
    :param endpoint: the enpoint to connect to.
    :type endpoint:  str
    :param sockType: the socket type to connect to.default REQ
    :type endpoint:  pyz.Req() or pyz.Dealer()
    """

    _proto_version = 'FMC-01'

    def __init__(self,service,endpoint='EndPoint',socketType = 'REQ'):
        """Initialize the MDPClient."""
        print ('Initializing MDPClient ' , service,':',endpoint,':',socketType)
        proto_p = ['', PROTO_VERSION, service]

	
        sT = pyz.SockType 
        sockType = sT(socketType)# get the object of sockType

        if isinstance(sockType,utl.getVal(pyz.SockTypes,'REQ')):
            proto_p = proto_p[1:] # first null not needed if Req type        
        elif isinstance(sockType,utl.getVal(pyz.SockTypes,'DEALER')): 
           pass
        else:
            sockType = sT('REQ')() # default request type

        socket = pyz.initSocket(sockType) # initializes the context also
        #context = zmq.Context()
        #socket = context.socket(zmq.REQ)
        ioloop = IOLoop.instance()
        self.service = service
        self.endpoint = endpoint
        self.stream = ZMQStream(socket, ioloop)
        self.stream.on_recv(self._on_message)
        self.can_send = True
        self._proto_prefix = proto_p
        self._tmo = None
        self.timed_out = False
        self.stream.connect('tcp://127.0.0.1:5555')
        #pyz.connect(socket,endpoint) # connect to the endPoint
        return

    def shutdown(self):
        """Method to deactivate the client connection completely.

        Will delete the stream and the underlying socket.

        .. warning:: The instance MUST not be used after :func:`shutdown` has been called.

        :rtype: None
        """
        if not self.stream:
            return
        self.stream.socket.setsockopt(zmq.LINGER, 0)
        self.stream.socket.close()
        self.stream.close()
        self.stream = None
        return

    def request(self, msg, timeout=None):
        """Send the given message.

        :param msg:     message parts to send.
        :type msg:      list of str
        :param timeout: time to wait in milliseconds.
        :type timeout:  int
        
        :rtype None:
        """
        print(' Client: Request ' + str(msg) )
        if not isinstance(msg,list):
            msg = [msg]

        if not self.can_send:
            raise InvalidStateError()
        # prepare full message
        to_send = self._proto_prefix[:]
        to_send.extend(msg)
        to_send = utl.toBytes(to_send)
        LogAudit(['Client Sending :',to_send])
        self.stream.send_multipart(to_send)
        self.can_send = False
        if timeout:
            self._start_timeout(timeout)
        return

    def _on_timeout(self):
        """Helper called after timeout.
        """
        self.timed_out = True
        self._tmo = None
        self.on_timeout()
        return

    def _start_timeout(self, timeout):
        """Helper for starting the timeout.

        :param timeout:  the time to wait in milliseconds.
        :type timeout:   int
        """
        self._tmo = DelayedCallback(self._on_timeout, timeout)
        self._tmo.start()
        return

    def _on_message(self, msg):
        """Helper method called on message receive.

        :param msg:   list of message parts.
        :type msg:    list of str
        """
        if self._tmo:
            # disable timout
            self._tmo.stop()
            self._tmo = None
        # setting state before invoking on_message, so we can request from there
        self.can_send = True
        self.on_message(msg)
        return

    def on_message(self, msg):
        """Public method called when a message arrived.

        .. note:: Does nothing. Should be overloaded!
        """
        pass

    def on_timeout(self):
        """Public method called when a timeout occured.

        .. note:: Does nothing. Should be overloaded!
        """
        pass
#
###

from zmq import select

def mdp_request(socket, service, msg, timeout=None):
    """Synchronous MDP request.

    This function sends a request to the given service and
    waits for a reply.

    If timeout is set and no reply received in the given time
    the function will return `None`.

    :param socket:    zmq REQ socket to use.
    :type socket:     zmq.Socket
    :param service:   service id to send the msg to.
    :type service:    str
    :param msg:       list of message parts to send.
    :type msg:        list of str
    :param timeout:   time to wait for answer in seconds.
    :type timeout:    float

    :rtype list of str:
    """
    if not timeout or timeout < 0.0:
        timeout = None
    if not isinstance(msg,list):
        msg = [msg]
    to_send = [b'',PROTO_VERSION, service]
    to_send.extend(msg)

    bsend = utl.toBytes(to_send)
    print(f"Sending request {bsend}")
    socket.send_multipart(bsend)
    ret = None
    rlist, _, _ = select([socket], [], [], timeout)
    if rlist and rlist[0] == socket:
        breakLoop = False
        while (not breakLoop): 
            ret = socket.recv_multipart()
            #print(f"Got Raw Reply {ret}")
            #ret.pop(0) # remove service from reply
            if not ret: # ret is none
                ret = {"ERROR": "TimedOut! No reply from broker"}

            breakLoop = ret[-1:] != [b'SEND_MORE']
            if not breakLoop: yield ret

    yield ret
#
###

### Local Variables:
### buffer-file-coding-system: utf-8
### mode: python
### End:
