# -*- coding: utf-8 -*-
"""
Created on Tue Oct  8 12:48:20 2019

@author: Shyam_Srinivasan
"""
import custom.customcalc as cc
from custom.includes import *
import cx_Oracle

@method(PreRequest,'ClientFNR')
def PreRequest(ReqMsg):
    # use config to get the type to put code for a specific type
    print('TIME PRE-REQUEST',time.ctime())
    print('CUSTOM PreRequest with msg ',ReqMsg)
    #defaultQ = ['select a.deal_type,a.deal_num ,b.deal_num,b.deal_type from all_deals a,all_deals b,all_deals c where 1=1']
    #defaultQ = ['select * from gl_trans_all_test']
    #defaultQ = ['select count(*) from gl_trans_all_test']
    #defaultQ = ['select * from gl_trans_all_test where rownum <=11000']
    #defaultQ = ['select * from gl_trans_all_test where rownum <=2']
    defaultQ = ['select sysdate from dual']
    customQ = [] #cc.GetEIRQuery()

    yield {"Query": customQ if len(customQ) else defaultQ
            ,"Service": 'FMW-01-TestService'}


@method(PostReply,'ClientFNR')
def PostReply(ReplyMsg):
    ## Delete debugs afterwards
    print('TIME POST-REPLY',time.ctime())
    #print(ReplyMsg)
    output = getVal(ReplyMsg,['DATA','Output','Data'],None)
    #print(output)
    llist=[v for k,v in output[0].items()] if output else []
    print('THE Reply i got is  :num of records ' , len(llist[0]))
    #cc.processAmort(output)
    yield ReplyMsg

