from custom.includes import *
import inspect
import os,json
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0,parentdir)

PROTO_VERSION = 'FMC-01'
SERVICES = {}
default_client_reply={'Output': {} , 'Messages': ['ERROR: Not valid !']} 

def ProcessFTQSQuery(ReplyMsg):
    QSList = getVal(ReplyMsg,'Query',None)
    serviceList = []
    newQSList = []
    for QS in QSList:
        if isinstance(QS['Service'], list):
            for service in QS['Service']:
                if not service in serviceList:
                    serviceList.append(service)
        else:
            serviceList.append(QS['Service'])

    serviceDict = dict((el,[]) for el in serviceList)

    for QS in QSList:
        if isinstance(QS['Service'], list):
            for service in QS['Service']:
                print(serviceDict[service])
                serviceDict[service].extend(QS['Query'])
        else:
            serviceDict[QS['Service']].extend(QS['Query'])

    for k,v in serviceDict.items():
        newQSList.append({'Query':v , 'Service' : k})

    return newQSList

def MakeEnvelope(msg):
    service = msg['Service']
    if not isinstance(msg,list):
        msg = [msg]
    to_send = [b'',PROTO_VERSION, service]

    return to_send


def sendToFTQSWorker(ReplyMsg):
    global SERVICES
    output = json.loads(ReplyMsg['Output'])
    if not ReplyMsg['SendMore']:
       print("No more from this service mark it as true..... ")
       SERVICES['FMW-01-'+output['Service']]['SendReady'] = True
       print(f"After the Services are {SERVICES}  ",[x['SendReady'] for x in SERVICES.values()])
       if all([x['SendReady'] for x in services.values()]):
           print("%%%%%%%%GOT ALL THE REPLYYYYYYYYYYYYY%%%%%%%%%%%%%%%%%%%%")
           ret = SERVICES
           return ret
       else:
           return None
    else:
       return None


def initiateServiceInfoMap(service):
    global SERVICES
    SERVICES[service]={'Dispatched':True,'Output':{},'SendReady':False}

def fromClient(msg):
    return not fromWorker(msg) 

def fromWorker(msg):
    return True if getVal(msg,'Output') else False 
    

@method(ProcessRequest,'FTQS')
def ProcessRequest(msg):
    print('ProcessRequest - FTQS:',ReplyMsg)
    #expecting ReplyMsg as a map which have 'Query' as a key and as a list as value for the query to run on services
    #Now for each query/service 
    #if request is like {Query : q5,Service : s5} then send that directly else make the query/service like that

 
    ret = None
    if fromClient(msg):
        ret = handle_client_msg(msg)
    elif fromWorker(msg):
        ret = handle_worker_msg(msg)

    return ret

def _validQueries(qlist):
    return True if len(qlist) > 0 else False


def handle_worker_msg(msg)
    global SERVICES
    print(f"Adding {msg} to list the Services are {services}")
    output = json.loads(msg['Output'])
    serviceKey = 'FMW-01-' + output['Service']
    print("OUTPUT is: ", output['Output']['Data'])
    print(SERVICES[serviceKey])
    if getVal(output,'Output.Data')!= "b''":
        SERVICES[serviceKey]['Output'] = utl.mergeDicts(SERVICES[serviceKey]['Output'],output)
    print("DONE MERGING : " ,SERVICES[serviceKey])

    x = sendToFTQSWorker(msg)

    if x is not None:
        yield x

def handle_client_msg(msg):
    #This is the actual request from client. 
    #So Make Sense of the query and send it to ftqs worker in a sensible format s1,s2,s3 ...
    #Also make the sevice info map updated with sendForProcessing as True Output as [] and toBeSend as False
    newQSList  = ProcessFTQSQuery(msg) 

    msg['Query'] = newQSList

    print('ProcessRequest - FTQS refactored: ' , msg)
    #Now Send that to different other workers as client
    qslist = msg['Query']
    to_send = default_client_reply
    if len(qslist) > 0:
        for q in qslist:
            print("processing query: " , q)
            service = q['Service']
            initiateServiceInfoMap(service)
            to_send = {service : {**SERVICES[service],**default_client_reply}}  
            if _validQueries(q):
                to_send = MakeEnvelope(q)
                if isinstance(q, list):
                    to_send.extend(q)
                else:
                    to_send.append(q)
            else:
                # send back to client.
                to_send = {service : {**SERVICES[service],**{'Messages':['Error: Not a valid query']}}}  

            print("Sending Reply: " , to_send)
            yield to_send
    else:
        yield to_send
