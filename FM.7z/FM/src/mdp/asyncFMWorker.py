"""
worker would initiate a worker based on the config and/or the 
command line arguement.
Connect to the MDP port in the MDP server.
Register with the service name that the worker is providing.
ServiceName : FC1-WQ  -- service on FC1 server/db and type WQ-Worker Query.
"""
import inspect
import os,zmq,importlib
from zmq.eventloop.ioloop import IOLoop
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0,parentdir)

import asyncio
import utils.pyutil as utl
import utils.pyz as pyz
from logger.logMsg import *

from asyncWorker import AsyncWorker , StartLoop
#from FTQS import FTQSWorker

class AsyncFMWorker(AsyncWorker):

    HB_INTERVAL = 2
    HB_LIVENESS = 3

    count = 0

    def ProcessInThread(self,m_input,loop):
        #print(f"ProcessInThread {m_input}")
        msg = utl.s2m(utl.toStr(m_input))
        #print(f"ProcessInThread {msg}")
        for ret in ProcessRequest(msg) :
            #print("Got ret : ",ret)
            asyncio.run_coroutine_threadsafe(self.queue.put(ret),loop)
        asyncio.run_coroutine_threadsafe(self.queue.put(None),loop) # end of the result generation

    async def consume_and_reply(self):
        while True:
            item = await self.queue.get()
            print(f'Item to be sent - ')
            if item is None :  # last item in the queue is None
                print("***BREAKING last item in the queue is None ****")
                break # wait for another request processing
            else:
                await self.reply(item)  # send the actual reply on port


    async def on_request(self, msg):
        self.count = self.count + 1
        #print('MEssage on Request is : ' , msg)
        # make processRequest as a separate thread. and put it in a event loop.
        loop = asyncio.get_event_loop()
        task1 = loop.run_in_executor(None,self.ProcessInThread,msg,loop)
        task2 = loop.create_task(self.consume_and_reply())
        
        await task1
        await task2


def ProcessRequest(msg):
    #print("PROCESS REQUEST Service Name is: ", utl.ProcessName(), " | ", utl.hooks() )
    #print([k for k,v in utl.hooks().items() if utl.ProcessName() in v])

    mymodule = utl.hooks()

    for ret in utl.customInvocation1(mymodule.ProcessRequest,msg):
        yield ret

def main(servicename=""):
    context = zmq.Context()

    if utl.getVal(utl.envfile(False),servicename,{}):
        utl.FMInit(servicename)
    else:
        utl.FMInit("FMW")

    InitLogger(os.path.basename(__file__))

    print("Starting worker for service : " ,servicename)

    utl.ProcessName(servicename)

    endPoint = pyz.getAddress("EndPoint")
    print("Worker EP : " , endPoint)

    #utl.ProcessName(utl.getVal(utl.Config(),'ProcessName','TestService'))# should be same as last part of service name
    #utl.ProcessName('TestService')
    #endPoint = utl.getVal(utl.Config(),'EndPoint',"tcp://127.0.0.1:55575")
    #endPoint = "tcp://127.0.0.1:55575"

    worker = AsyncFMWorker(endPoint)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(StartLoop(worker))

