# -*- coding: utf-8 -*-
"""
Created on Mon Oct  7 11:20:39 2019

@author: Shyam_Srinivasan
"""

envDefaults = {
        'FM_CONFIG_FILE':'D:\\Code\\python\\mdp\\pyzmq-mdp-0.2\\utils\\fm.config',
        'FM_CUSTOM_PATH':'/users/e765738/ftfm/newfm/FM/custom/'
        }
