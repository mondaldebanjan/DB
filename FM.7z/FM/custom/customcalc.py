import pandas as pd
from utils import pyutil as utl
from custom.xirr import xirr 
import json


def GetSampleFTQSQuery():
    DUALQ = 'Select sysdate from dual'
    GL_Q = 'select JNLREF,ACCNUM from GL_TRANS_ALL where rownum<5'
    #GL_Q = 'select JNLREF,ACCNUM from GL_TRANS_ALL'
    return [{'Query':[DUALQ],'Service':'FMW-01-TestService'},{'Query':[GL_Q],'Service':'FMW-01-GLService'},{'Query':[DUALQ],'Service':['FMW-01-GLService','FMW-01-TestService']}]
    #return [{'Query':[DUALQ],'Service':'FMW-01-TestService'},{'Query':[GL_Q],'Service':'FMW-01-GLService'}]
   

def GetFNRFTQSQuery():
    DUALQ = 'Select user,sysdate from dual'
    GL_Q= 'Select * from GL_TRANS_ALL where rownum<2'
    #DUALQ1 = "SELECT  NVL ( LTRIM ( SUBSTR ( t.TRAN_PARTICULAR, 1, 30 ) ), 'NONE' ) REF_NUM, t.TRAN_DATE || '-' || LTRIM ( t.TRAN_ID ) || '-' || LTRIM ( t.PART_TRAN_SRL_NUM ) INT_REF_NUM, g.foracid ACC_NUMBER, t.TRAN_AMT AMOUNT, t.TRAN_CRNCY_CODE CCY, t.PART_TRAN_TYPE DRCR, to_char(t.VALUE_DATE,'DD-Mon-YYYY') VALUE_DATE, to_char(t.TRAN_DATE,'DD-Mon-YYYY') ENTRY_DATE, 'NONE' TXN_TYPE, 'NONE' TXN_SUBTYPE, 'NONE' DEPT, c.init_sol_id ENTITY, 'NONE' CPTY, 'NONE' LBS_FIELD_1, 'NONE' LBS_FIELD_2, 'NONE' LBS_FIELD_3, 'NONE' LBS_FIELD_4, 'NONE' LBS_FIELD_5, 'NONE' LBS_FIELD_6, 'NONE' LBS_FIELD_7, 'NONE' LBS_FIELD_8, 'NONE' LBS_FIELD_9, 'NONE' LBS_FIELD_10, 'NONE' LBS_FIELD_11, 'NONE' LBS_FIELD_12 FROM  TBAADM.GAM g, TBAADM.HTD t, TBAADM.HTH c  WHERE  t.ACID = g.ACID and g.bank_id=t.bank_id and g.bank_id=c.bank_id and t.bank_id=c.bank_id and (t.tran_id) = (c.tran_id) and t.tran_date = c.tran_date  and g.acct_ownership = 'O' and t.DEL_FLG = 'N' and c.del_flg = 'N' AND  t.SOL_ID IN (001) AND t.TRAN_DATE between to_date('01-May-2011','DD-MM-YYYY') and to_date('29-May-2011','DD-MM-YYYY') and rownum <4"

    #return [{'Query':[GL_Q],'Service':['FMW-01-CORE-1','FMW-01-CORE-2']}]
    #return [{'Query':{"FIRST":DUALQ,"SECOND":"Select user,sysdate from dual"},'Service':['FMW-01-CORE-3']}]
    #return [{'Query': { "FIRST": {"stored_sql":"RECON_EXTRACT" ,"AppendWC" : "t.SOL_ID IN (001,002) AND t.TRAN_DATE between to_date('01-May-2011','DD-MM-YYYY') and to_date('29-May-2011','DD-MM-YYYY') and rownum<4"}} ,'Service':['FMW-01-CORE-3']}]
    return [{"Query":{"NOSTRO_BAL_001" : "SELECT  NVL ( LTRIM ( SUBSTR ( t.TRAN_PARTICULAR, 1, 30 ) ), 'NONE' ) REF_NUM, t.TRAN_DATE || '-' || LTRIM ( t.TRAN_ID ) || '-' || LTRIM ( t.PART_TRAN_SRL_NUM ) INT_REF_NUM, g.foracid ACC_NUMBER, t.TRAN_AMT AMOUNT, t.TRAN_CRNCY_CODE CCY, t.PART_TRAN_TYPE DRCR, to_char(t.VALUE_DATE,'DD-Mon-YYYY') VALUE_DATE, to_char(t.TRAN_DATE,'DD-Mon-YYYY') ENTRY_DATE, 'NONE' TXN_TYPE, 'NONE' TXN_SUBTYPE, 'NONE' DEPT, c.init_sol_id ENTITY, 'NONE' CPTY, 'NONE' LBS_FIELD_1, 'NONE' LBS_FIELD_2, 'NONE' LBS_FIELD_3, 'NONE' LBS_FIELD_4, 'NONE' LBS_FIELD_5, 'NONE' LBS_FIELD_6, 'NONE' LBS_FIELD_7, 'NONE' LBS_FIELD_8, 'NONE' LBS_FIELD_9, 'NONE' LBS_FIELD_10, 'NONE' LBS_FIELD_11, 'NONE' LBS_FIELD_12 FROM  TBAADM.GAM g, TBAADM.HTD t, TBAADM.HTH c  WHERE  t.ACID = g.ACID and g.bank_id=t.bank_id and g.bank_id=c.bank_id and t.bank_id=c.bank_id and (t.tran_id) = (c.tran_id) and t.tran_date = c.tran_date  and g.acct_ownership = 'O' and t.DEL_FLG = 'N' and c.del_flg = 'N' AND  t.SOL_ID IN (001) AND t.TRAN_DATE between to_date('01-May-2011','DD-MM-YYYY') and to_date('29-May-2011','DD-MM-YYYY') and  rownum<2"},"Service" : ["FMW-01-CORE-3"]} , {"Query":{"NOSTRO_BAL_002" : "SELECT  NVL ( LTRIM ( SUBSTR ( t.TRAN_PARTICULAR, 1, 30 ) ), 'NONE' ) REF_NUM, t.TRAN_DATE || '-' || LTRIM ( t.TRAN_ID ) || '-' || LTRIM ( t.PART_TRAN_SRL_NUM ) INT_REF_NUM, g.foracid ACC_NUMBER, t.TRAN_AMT AMOUNT, t.TRAN_CRNCY_CODE CCY, t.PART_TRAN_TYPE DRCR, to_char(t.VALUE_DATE,'DD-Mon-YYYY') VALUE_DATE, to_char(t.TRAN_DATE,'DD-Mon-YYYY') ENTRY_DATE, 'NONE' TXN_TYPE, 'NONE' TXN_SUBTYPE, 'NONE' DEPT, c.init_sol_id ENTITY, 'NONE' CPTY, 'NONE' LBS_FIELD_1, 'NONE' LBS_FIELD_2, 'NONE' LBS_FIELD_3, 'NONE' LBS_FIELD_4, 'NONE' LBS_FIELD_5, 'NONE' LBS_FIELD_6, 'NONE' LBS_FIELD_7, 'NONE' LBS_FIELD_8, 'NONE' LBS_FIELD_9, 'NONE' LBS_FIELD_10, 'NONE' LBS_FIELD_11, 'NONE' LBS_FIELD_12 FROM  TBAADM.GAM g, TBAADM.HTD t, TBAADM.HTH c  WHERE  t.ACID = g.ACID and g.bank_id=t.bank_id and g.bank_id=c.bank_id and t.bank_id=c.bank_id and (t.tran_id) = (c.tran_id) and t.tran_date = c.tran_date  and g.acct_ownership = 'O' and t.DEL_FLG = 'N' and c.del_flg = 'N' AND  t.SOL_ID IN (001) AND t.TRAN_DATE between to_date('01-May-2011','DD-MM-YYYY') and to_date('29-May-2011','DD-MM-YYYY') and rownum<2"},"Service" : ["FMW-01-CORE-3"]}]

def GetEIRQuery():
    SECDEFN_CF= '''select name,to_char(start_date) start_date,to_char(end_date) end_date,
	 		Notional_amount_value amount,settlement_value_value,basis_code,fix_rate 
			from tt_secdefn_cash_flows scf , sd_sec_defn df
			where scf.parent_fbo_id_num = df.fbo_id_num
			/*and df.name = 'CG7.94-2021'*/
	          	and scf.parent_fbo_id_ver = 999999
		        and scf.subtype in ('MAIN','EXCP') 
			order by name,end_date''' 
    SEC_BS= '''Select bs.deal_num,bs.buy_or_sell,bs.qty_open,bs.qty_traded,bs.price
		     		,bs.settlement_value,to_char(bs.settlement_date) settle_date
		       		,sd.name defn_name,bs.link1_deal_id_num		
				from tt_sec_bs bs,sd_sec_defn sd 
		      	where 
				sd.fbo_id_num = bs.sec_defn_fbo_id_num
				and sd.name = 'CG7.94-2021'
				and bs.deal_state in (select name from sd_live_deal_states where live='Y')
				order by bs.link1_deal_id_num,sd.name '''
    return [SECDEFN_CF,SEC_BS]
                  

def col2Date(df):
    dtCols = list(df.columns)
    dtCols = list(filter(lambda x:x.endswith('_DATE'),dtCols))
    print('DATE cols ',dtCols)
    for col in dtCols:
        df[col]= df[col].astype('datetime64[ns]')


def getAI(sdt,edt,stdt,stamt,basis=365):
    print('INSIDE getAI', sdt,edt,stdt,stamt)
    AI=0
    if stdt != sdt:
        AI = (edt-stdt)/(edt-sdt)*stamt
    print('AI-> ',AI)
    return AI


def eir(p,fsd):
    
    xirval = None
    stdt = p.SETTLE_DATE
    setdt = utl.npdt64_to_datetime(stdt).date() 
    dSettAmt = p.BV 

    amtList = [(setdt, - dSettAmt)]
    cf = fsd[fsd['END_DATE'] > stdt][['END_DATE','SETTLEMENT_VALUE_VALUE']]
    amtList = amtList + [(row.END_DATE.date(),row.SETTLEMENT_VALUE_VALUE*p.NET_QTY_OPEN/row.AMOUNT) for row in cf.itertuples()]
    print('amtList for xirr',amtList)
    xirval = xirr(amtList)
    p['XIRR'] = xirval
    return p
    

def processEIR(name,fsd,fdl):
    settDtList = fdl['SETTLE_DATE'].unique()
    pos = createPos(fsd,fdl)
    print('UNIQUE sett dates ' , settDtList)
    return (name,[eir(pos,fsd)])

def findEIROnDealDates(sd,dl):
    col = 'NAME'
    secNames = dl[col].unique()
    def f(df,n):
        return df[df[col] == n]
    return [processEIR(n,f(sd,n),f(dl,n)) for n in secNames]


def processAmort (m) :
    print(list(m))
    cfDetails = utl.getVal(m,'0',None) 
    dealDetails = utl.getVal(m,'1',None)

    dfcf = pd.DataFrame(cfDetails)
    dfDeal = pd.DataFrame(dealDetails)

    col2Date(dfcf)
    col2Date(dfDeal)

    dfcf.info()
    dfDeal.info()
    dfDeal['NAME']=dfDeal['DEFN_NAME']

    #print(dfcf)
    #print(dfDeal)
    buyDeals = dfDeal[dfDeal['BUY_OR_SELL'] == 'B']
    hdgEirDict = findEIROnDealDates(dfcf,buyDeals)
    print('=================================================')
    #print(json.dumps(hdgEirDict,default=str,indent=4))

