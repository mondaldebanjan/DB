from custom.includes import *
import time

@utl.method(ProcessRequest,'TestService')
def ProcessRequest(ReqMsg):
    print('ProcessRequest - TestService ASYNC: ' , ReqMsg)
    queries = utl.getVal(ReqMsg,"Query",None) 
    queries = FormQuery(queries) 
    for rows in db.SelectIter(queries,'ASYNC'):
        ret = utl.formReply(rows,more=True)
        yield ret
    yield utl.formReply(b'')

@method(ProcessRequest,'GLService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - GLService ASYNC: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    print('TIME PRE-DB Select',time.ctime())
    for rows in db.SelectIter(queries,'ASYNC'):
        ret = utl.formReply(rows,more=True)
        yield ret
    yield utl.formReply(b'')


