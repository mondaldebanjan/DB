# -*- coding: utf-8 -*-
import inspect
import os
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0,parentdir)

import utils.pyz as pyz
import utils.pyutil as utl
import custom.customScripts as custom
import functools
from zmq.eventloop.ioloop import IOLoop
from logger.logMsg import *


from client import MDPClient, mdp_request

class FMClient(MDPClient):

    def on_message(self, res):
        print("FMClient:on_message Received:", repr(res))
        IOLoop.instance().stop()
        return

    def on_timeout(self):
        print('TIMEOUT!')
        #IOLoop.instance().stop()
        return
                                          

def PreRequest(ReqMsg):
    '''Request:
        {"Query":['give your query'],\
        "Service": ['give your service name'],\
        "Name" : "Name is optional.Used to identify the query"}
    '''
    utl.ProcessName('Client-1') # should come from cmdline. can be set in the custom invocation.
    ret = next(utl.customInvocation1(custom.PreRequest,ReqMsg))

    return ret


def PostReply(RepMsg):
    ''' Calls custom function after getting reply.
	Can call utl.SendAndRec again and again in a loop if needed.
	However , it works on a Req->Reply->Req->Reply cycle. Non-Async.
	For truely Async requests, use FTQS'''
    return next(utl.customInvocation1(custom.PostReply,RepMsg))

def SendAndRecieveDefault(socket,RMsg,timeOut=20,mode='SYNC'):

    def sendAndRec(msg={}):
        msg = {**RMsg,**msg}
        ReqMsg = {**RMsg,**PreRequest(msg)}# default woul+d be available. override with type
        resColl = []
        
        #print('Actual ReqMsg',ReqMsg)
        service = utl.getVal(ReqMsg,"Service",'INVALID')
        tout = utl.getVal(ReqMsg,"TimeOut",timeOut)
        for res in  mdp_request(socket, service ,ReqMsg, tout):

            reply = res if res else ['NONE',{'TIMEOUT': True}]
            #print(f"MSG at FMCLIENT before pop {reply}")
            moreMsg = {}
            reply = reply[3:] # take out the server info
	
            if reply[-1:] == [b'SEND_MORE']: 
                moreMsg = {'SEND_MORE':True} 
                reply = reply[:-1] # drop the last item 'SEND_MORE'  as it is not part of json message
            else : 
                moreMsg = {}

            #print(f" MSG at FMCLIENT - > {reply}")
            repMsg = utl.s2m(utl.toStr(reply)) 
            repMsg = {**repMsg,**moreMsg}
            #print(f" repMsg type -> {type(repMsg)}")
            #print('add data recieved')
            #print("PROCESS NAME => ",utl.ProcessName())
            if mode == 'ASYNC' :
                PostReply(repMsg) # default availble,override with type , should be single dispatch
            else :
                resColl.append(repMsg)

        resultColl = None
        if resColl and resColl != [] :
            resultColl = functools.reduce(utl.mergeDicts,resColl)
        print(resultColl)
        PostReply({'DATA': resultColl})  # if ASYNC , then the last message will be null list []

    return sendAndRec
        


def main(cltype=""):
    ''' To initialize config and sockets and query on the workers. 
    Get response to it.'''
    
    utl.FMInit('FMC') # Init context , socket , type<FMC>, endpoint
    InitLogger(os.path.basename(__file__))
    utl.ProcessName(cltype)
    #pName = utl.ProcessName(utl.getVal(utl.Config(),'ProcessName','Client-1'))
    #print(utl.Config())
    print("PROCESS NAME => ",utl.ProcessName())
    
    socket = pyz.initSocket(pyz.Dealer())
    pyz.connect(socket,"EndPoint") # connect to the endpoint in env
    
    # default reqest type
    ReqMsg = {"Query":['Select sysdate from dual'],\
              "Service": 'echo'}
    utl.SendAndRec = SendAndRecieveDefault( socket,ReqMsg)
    
    #try:
    res = utl.SendAndRec()
        
    #except Exception as e:
    #LogError(['Client could not connect',e])         
