import cx_Oracle
import zlib
import pickle
import json
import time


def recv_zipped_pickle(receiver, flags=0):
    """reconstruct a Python object sent with zipped_pickle"""
    zobj = receiver.recv(flags)
    pobj = zlib.decompress(zobj)
    return pickle.loads(pobj)

def recv_zipped_pickle_multipart(receiver, flags=0):
    """reconstruct a Python object sent with zipped_pickle"""
    zhead, zobj = receiver.recv_multipart()
    pobj = zlib.decompress(zobj)
    phead = zlib.decompress(zhead)
    return pickle.loads(phead),pickle.loads(pobj)

def send_zipped_pickle(sender, obj, flags=0,protocol=-1):
    """pack and compress an object with pickle and zlib."""
    pobj = pickle.dumps(obj, protocol)
    zobj = zlib.compress(pobj)
    sender.send(zobj, flags=flags)

def send_zipped_pickle_multipart(sender, obj,header,protocol=-1):
    """pack and compress an object with pickle and zlib."""
    pobj = pickle.dumps(obj, protocol)
    zobj = zlib.compress(pobj)

    phead = pickle.dumps(header, protocol)
    zhead = zlib.compress(phead)
    sender.send_multipart([zhead, zobj])
