MDP client module
=================

.. automodule:: mdp.client
   :members:
   :member-order: bysource

