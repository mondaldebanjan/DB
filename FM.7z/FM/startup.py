import time,os,inspect
from  multiprocessing import Process
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0,parentdir)
os.sys.path.insert(0,"./src/mdp")
os.sys.path.insert(0,"./src/")
#os.sys.path.insert(0,"../../custom/")
from mdp import fmbroker,fmworker,fmclient,asyncFMWorker
import utils.pyutil as utl
import logger.logMsg as lg
import logger.BufferedLogCollectorToFile as lc

custompath = utl.getSysEnv('FM_CUSTOM_PATH')
print(custompath)
os.sys.path.insert(0,custompath)

def Start(source='CMD',args={}):
    if source=='CMD':
        args = vars(utl.ParseCmdLine("V1.0"))

    print(args)

    #Starts the Log Collector Process
    if not args['nolog']:
        p = Process(target=lc.main, args=())
        p.start()

    #Starts the 
    if args['broker']:
        p = Process(target=fmbroker.main, args=())
        p.start()
        print("Waiting Before Broker is Ready... ")
        time.sleep(3)
 
    if args['worker'] is not None:
        i = iter(args['worker'])
        workers = dict(zip(i, i))
        #print(workers)
        for w,nums in workers.items():
            for n in range(int(nums)):
                #print("Startung worker number",n+1)
                p = Process(target=asyncFMWorker.main, args=(w,))
                p.start()
        print("Waiting Before Workers are registered... ")
        time.sleep(3)

    if args['client'] is not None:
        p = Process(target=fmclient.main, args=(args['client'][0],))
        p.start()

    #if args['httpclient']:
    #   p = Process(target=httpclient.main, args=())
    #   p.start()


if __name__ == '__main__':
    Start()


