import os,inspect 
import utils.pyutil as utl
from logger import ZLoggerTopic
import logging
import socket

logger = None

def InitLogger(filename):
    global logger
    LoggingEndpoint = utl.getVal(utl.Config(None),"LoggingEndpoint")
    print("Loggint in Endpoint : " , LoggingEndpoint) 
    server = socket.gethostname()
    logger = ZLoggerTopic(LoggingEndpoint,server,filename,logging.DEBUG)

def LogError(inMsg):
    logger.ZLogError(inMsg)


def LogAudit(inMsg):
    logger.ZLogAudit(inMsg)

def LogWarning(inMsg):
    logger.ZLogWarning(inMsg)


def main():
    utl.FMInit('FMLOGGER')
    InitLogger()
