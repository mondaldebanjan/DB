from custom.includes import *
import time

def Process(ReqMsg):
    queries = utl.getVal(ReqMsg,"Query",None)
    #queries = FormQuery(queries) 
    for rows in db.SelectIter(queries,'ASYNC'):
        ret = utl.formReply(rows,more=True)
        yield ret
    yield utl.formReply(b'')


@utl.method(ProcessRequest,'CORE-1')
def ProcessRequest(ReqMsg):
    print('ProcessRequest - CORE-1 ASYNC: ' , ReqMsg)
    yield from Process(ReqMsg)

@utl.method(ProcessRequest,'CORE-2')
def ProcessRequest(ReqMsg):
    print('ProcessRequest - CORE-2 ASYNC: ' , ReqMsg)
    yield from Process(ReqMsg)

@utl.method(ProcessRequest,'CORE-3')
def ProcessRequest(ReqMsg):
    print('ProcessRequest - CORE-3 ASYNC: ' , ReqMsg)
    yield from Process(ReqMsg)

@utl.method(ProcessRequest,'CORE-4')
def ProcessRequest(ReqMsg):
    print('ProcessRequest - CORE-4 ASYNC: ' , ReqMsg)
    yield from Process(ReqMsg)
