import db.dbutil as db
import time
from multipledispatch import dispatch
from utils.pyutil import multi , method , getVal, formReply
import utils.pyutil as utl
from logger.logMsg import *
from custom.stored_sqls import *

# has the interface for custom queries.

@multi
def PreRequest(ReqMsg):
    return getVal(ReqMsg,'ProcessName')
    #assert 0 , f"Custom PreRequest not supporeted for dType:{x} and dType:{y}"

@multi
def PostReply(ReqMsg):
    return getVal(ReqMsg,'ProcessName')
    #assert 0 , f"Custom PreRequest not supporeted for dType:{x} and dType:{y}"

@multi
def ProcessRequest(ReqMsg):
    print(f' In ProcessRequest-MULTI- reqMsg {ReqMsg}')
    return  getVal(ReqMsg,'ProcessName')


@method(ProcessRequest,None)
def ProcessRequest(ReqMsg):
    print(f' In ProcessRequest-method- reqMsg {ReqMsg}')
    LogError(['Default ProcessRequest... No implementation'])

def validateSQL(sql):
    '''TODO'''
    if sql:
       return True
    return False

def AppendQ(q):
    try:
        if not validateSQL(getVal(q,'sql')):
            print("AppendQ : ", getVal(stored_vars,getVal(q,'stored_sql')))
            #stored_sql = eval(getVal(q,'stored_sql'))
            if getVal(stored_vars,getVal(q,'stored_sql'))["type"]=="F":
                return getVal(stored_vars,getVal(q,'stored_sql'))["val"]

            stored_sql = getVal(stored_vars,getVal(q,'stored_sql'))["val"]
        else:
            stored_sql = getVal(q,'sql')

        if q['AppendWC']:
            stored_sql = stored_sql + " and " + q['AppendWC']

        print("Sql is :" , stored_sql)
        return stored_sql
    except NameError as error:
        print("NO Stored SQL Found!")
        return None

def FormDictQueries(queries):
    for name,q in queries.items():
        if isinstance(q,dict):
           queries[name] = AppendQ(q)

    return queries

def FormListQueries(queries):
    result = []
    for q in queries:
        if isinstance(q,dict):
            result.append(AppendQ(q))
        elif isinstance(q,str):
            result.append(q)

    return result

def FormQuery(queries):
    #find if the query is a dict or list
    print("forming queries: " , queries)

    if isinstance(queries,list):
        return FormListQueries(queries)
    elif isinstance(queries,dict):
        return FormDictQueries(queries)
