import time
import zmq
from logger.transferUtils import *
from  multiprocessing import Process
import logging
from logging.handlers import MemoryHandler,RotatingFileHandler
import utils.pyutil as utl


loggerMap={}

def PutLogTofile(pid,logs):
    global loggerMap
    if pid not in loggerMap.keys():
        #Create a logHandler and set that as value
        logger = logging.getLogger(pid)
        logger.setLevel(logging.DEBUG)

        #max 1000 Bytes in a file then back up
        logpath = utl.getSysEnv("FM_LOG_DIR")
        print("Log path is: ",logpath)
        target_handler = RotatingFileHandler(logpath+"/"+pid+".log", maxBytes=utl.getVal(utl.Config(None),"FileMaxBytes",None), backupCount=utl.getVal(utl.Config(None),"NumBkp",None))

        #Putting 10 line in buffer or if level is error
        handler = MemoryHandler(10, flushLevel=logging.ERROR, target=target_handler)

        logger.addHandler(handler)
        loggerMap[pid] = logger

    #add the log to using the hndler
    loggerMap[pid].info(logs)
        

    
def file_logger_client():
    context = zmq.Context()
    receiver = context.socket(zmq.PULL)
    try:
        receiver.bind('tcp://*:' + utl.getVal(utl.Config(None),"FileLogPort",None))
    except zmq.error.ZMQError:
        print("Collector port already Running")
    while True:
        topic,log = receiver.recv_multipart()
        logstr = log.decode()
        pid = topic.decode().split('.')[1]
        PutLogTofile(pid,logstr)


#Published the messages here any customisation can be done below
def sub_logger(port, level=logging.DEBUG):
    ctx = zmq.Context()
    sub = ctx.socket(zmq.SUB)
    try:
        #sub.bind('tcp://127.0.0.1:%i' % port)
        sub.bind('tcp://*:'+ port)
    except zmq.error.ZMQError:
        print("Sub Collector port already Running")
    sub.setsockopt_string(zmq.SUBSCRIBE, "")
    logging.basicConfig(level=level)

    while True:
        level, message = sub.recv_multipart()
        print(message.decode())

def main():
    print("Collecting log....")
    utl.FMInit('FMLOGCOLLECT')
    subport = utl.getVal(utl.Config(None),"SubscribePort",None)
    #Process(target=sub_logger, args=(subport,)).start()
    #Process(target=file_logger_client, args=()).start()

if __name__ == '__main__':
    main()
