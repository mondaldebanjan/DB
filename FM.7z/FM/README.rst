FM - for mircroservices 
***********************

FM  infrastructure will serve as a hub that can direct requests and works to different services asynchronously. 
It will also give a framework to easily add new services (in a matter of 2-3 days, instead of weeks) , and can serve well for customizations and ad-hoc services.

One of the main objectives is to separate out the FT core business with adjoining services that are needed in order to fit in an Enterprise architecture. However the design is not restricted to FT , and can be  stand-alone integrating different products and services.

The illustration below would give a basic overview of the FM landscape.

.. figure: docsource/images/FM-Overview.png
   :align: center

FM Broker
=========
FM broker is the hub that orchestrates the Requests and Replies.
All requests come to FM Broker and gets routed to the respective services as given in the message. Once the services reply to the broker, it then forwards the reply to the correct client.

All the services(workers) register themselves to the broker once they start up. As soon as the workers start up , they sendtheir message to broker for registry. Also a heartbeat request loop is started that goes on till the worker or broker goesdown. This is to keep the ports open even when there are no requests.

The following happens once a client request reaches broker:
   * Broker receives client request.
   * Parses message to find service.
      - Finds service that is needed.
         - If Worker is *free* then sends the request. Marks the worker as *Busy*
         - If Worker is *Busy* then puts the message in the queue. This will get picked up once any of the worker is free.
      - Service not found. Return an error message to the client.
   * Get reply from worker.
      - Send reply to the corresponding client. If more replies are expected then keep worker *busy*. If no more replies are expected then mark worker *free*.


Currently broker doesn't store the requests or replies in a file or database. 
Hence in the event of failure or a crash , there would be no way of recovery of the request. 
The request would have to be replayed.

*This implementation in Python is using pyzmq(aiozmq).
For the specification of 0MQ see* `The Majordomo Protocol <http://rfc.zeromq.org/spec:7>`_
