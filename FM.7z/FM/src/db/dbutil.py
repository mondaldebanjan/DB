# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 14:56:12 2019

@author: Shyam_Srinivasan
"""

import cx_Oracle as cxo
import utils.pyutil  as utl
from multipledispatch import dispatch

DNS = "ftdb=\
(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (COMMUNITY =)\
 (PROTOCOL = TCP) (HOST = 10.66.118.213) (PORT = 1523))) \
(CONNECT_DATA = (SID = ftdb)))"
user = 'infy2'
passwd = 'LMP789QR'
rowfactory = lambda *args: dict(zip([d[0] for d in cur.description], args))
connStr = user+'/'+passwd+'@'+'10.66.118.213:1523/ftdb'
connStr = utl.getConnStr() or utl.connStr

# con close and connect should be inside try: execption: block
def Con(x=None):
    ''' get connection if not there . close connection if passed close'''
    mcon = {'_NONE_': None}
    def conhelper(x='_NONE_'):
        if x in ['CLOSE','C'] and mcon['_NONE_']:
            con = mcon['_NONE_']
            con.close() 
            mcon['_NONE_'] = None 
        else:
            con = mcon['_NONE_']
            mcon['_NONE_'] = con if con  else cxo.connect(connStr)
        return con

    return conhelper

# This is a generator function.
def SelectWithConnection(con,clause,arraySize=1000):
    rows=[]
    print('TYPE OF CONNECTION: ',type(con))
    try:
        print('IN TRY BLOCK of Select')
        cur = con.cursor()
        cur.execute(clause) # shouldnt you prepare the statement first and also use bind variables?
        cur.arraysize= arraySize 
        cur.rowfactory=  lambda *args: dict(zip([d[0] for d in cur.description], args))# convert rows to maps
        while True:
            rows = cur.fetchmany() # fetches maps of data
            print('Rows selected ',len(rows))
            if len(rows) :
                yield rows
            else:
                break
    except cxo.DatabaseError as e:
        print("ERROR ERROR: Problem while selecting with connection object->",e)

def iterSelect(c,cl,size=1000):
    # TODO: get arraysize from config
    rows = []
    selList = SelectWithConnection(c,cl,size)# can give size if required.
    while True:
        r =  next(selList)
        #print("Returned with r len -> :" , len(r))
        if len(r) :
            rows = rows + r 
            #print('ROWS RETURNED ' , len(rows))
            if len(r) < asize :
                break
        else:
            break
    print('Total Rows selected ' , len(rows))
    return rows


@dispatch(dict)
def Select(mclauses):
    print('Coming to Select->dict')
    connStr = utl.getConnStr() or utl.connStr
    c=cxo.connect(connStr)
    ret = dict( [(k,iterSelect(c,clause,size)) for k,clause in mclauses.items()])
    c.close()

    #print(f"Select->dict ret = {ret}")
    return ret 


@dispatch(dict,str)
def Select(mclauses,mode):
    connStr = utl.getConnStr() or utl.connStr
    print(connStr)
    print(f'Coming to Select->dict,{mode}')
    if mode == 'SYNC':
        yield Select(mclauses)
    else :
        c=cxo.connect(connStr)
        for k,clause in mclauses.items():
            #yield dict( [(k,r) for r in SelectWithConnection(c,clause) ])  
            for r in SelectWithConnection(c,clause) :
                print(f"Async .. Select yielding {k}-> {len(r)}")
                yield {k:r}



@dispatch(list,str)
def Select(clauses,mode):
    ''' Take in a list of clauses and return the results in a map '''
    mclauses = dict([("Q_"+str(i),clause) for i,clause in enumerate(clauses) ])
    for ret in Select(mclauses,mode):
        yield ret 
        
@dispatch(str,str)
def Select(clause,mode):
    ''' Take a str and give back the result in a map '''
    if not isinstance(clause,str): 
        yield None
    else :
        for ret in Select([clause],mode): 
            yield ret

def SelectIter(cl,mode='SYNC'):
    for ret in Select(cl,mode):
        yield ret
