
from custom.includes import *



@method(ProcessRequest,'Worker-2')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - Worker-2: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None) 
    rows = db.Select(queries)
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": rows}}
    return ReplyMsg
