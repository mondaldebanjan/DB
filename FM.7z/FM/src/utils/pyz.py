import zmq
from . import pyutil as utl
from multipledispatch import dispatch
from logger.logMsg import *

#types defined. for dispatch
class Sub:
    pass
class Req:
    pass
class Rep:
    pass
class Pub:
    pass
class Dealer:
    pass
class Router:
    pass

SockTypes = {'REQ':Req,'REP':Rep,'DEALER':Dealer,'ROUTER':Router,'PUB':Pub,'SUB':Sub} 

def SockType(t):
    ret = None
    if isinstance(t,tuple(SockTypes.values())):
        ret= t
    else:
        if isinstance(t,str):
            ret = utl.getVal(SockTypes,t)() # get the obj of type

    return ret 


@utl.memoize
def context(x='_NONE_'):
    ''' Memoize makes this singleton '''
    return zmq.Context()

@dispatch (Sub)
def initSocket(sockType):
    sock = context().socket(zmq.SUB)
    sock.setsockopt(zmq.SUBSCRIBE)
    sock.setsockopt(zmq.LINGER,0)
    return sock

@dispatch (Pub)
def initSocket (sockType):
    return context().socket(zmq.PUB)

@dispatch (Req)
def initSocket (sockType):
    print('in InitSocket - ' + str(type(sockType)))
    sock = context().socket(zmq.REQ)
    sock.setsockopt(zmq.LINGER, 0)
    return sock

@dispatch (Rep)
def initSocket (sockType):
    return context().socket(zmq.REP)

@dispatch (Dealer)
def initSocket (sockType):
    sock= context().socket(zmq.DEALER)
    sock.setsockopt(zmq.LINGER, 0)
    return sock

@dispatch (Router)
def initSocket (sockType):
    sock= context().socket(zmq.ROUTER)
    sock.setsockopt(zmq.LINGER, 0)
    return sock

def getAddress(add):
    ''' Checks if the address is a valid endPoint. If not , checks the config to find address for the key give.
	return None if no valid address found'''
    address = add
    if not isValidEndPoint(add):
        address = utl.getVal(utl.Config(None),add,None)

	#check if config address is valid
        #if not isValidEndPoint(address):
        #   address = None

    return address

def isValidEndPoint(endPoint):
    ''' check if endpoint is of the form ...''' 
    return False

def connect(sock,add):
    ''' Given an address , take the address if valid or from env & connect'''
    address = getAddress(add)
    LogAudit('Connecting with add:'+add+' address: ' + address)

    assert address, "connect:Cannot find valid EndPoint for: " + add
    try:
        con= sock.connect(address)
    except:
    	LogError("connect:Could not connect to socket with address " + add)

    return con

def bind(sock,add):
    ''' Given an address , take the address if valid or from env & bind'''
    address = getAddress(add)
    LogAudit('Binding with add:'+add+' address: ' + address)
    assert address, "bind:Cannot find valid EndPoint for: " + add
    try:
        con = sock.bind(address)
    except:
        LogError("bind:Could not bind to socket with address " + add)
