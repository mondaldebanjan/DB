MDP worker module
=================

.. automodule:: mdp.worker
   :members:
   :member-order: bysource

