.. ØMQ Majordomo Protocol Implementation documentation master file, created by
   sphinx-quickstart on Mon Mar  7 08:23:36 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ØMQ Majordomo Protocol Implementation's documentation!
=================================================================

.. automodule:: mdp

Contents
--------

.. toctree::
   :maxdepth: 2

   client
   worker
   broker
   util


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

