import inspect
import os
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0,parentdir)
import utils.pyutil as utl
import utils.pyz as pyz
from logger.logMsg import *
import zmq
from zmq.eventloop.ioloop import IOLoop
import os

from broker import MDPBroker

class FMBroker(MDPBroker):
    pass


def main():
    utl.ProcessType('FMB')
    utl.FMInit("FMB")
    InitLogger(os.path.basename(__file__))
    context = zmq.Context()
    ep = pyz.getAddress("EndPoint")
    print("Broker EP : " , ep)

    broker = FMBroker(context, ep)
    IOLoop.instance().start()
    broker.shutdown()

