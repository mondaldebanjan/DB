
from custom.includes import *
import custom.customcalc as cc
import zmq
import inspect,cx_Oracle
import os
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0,parentdir)

import utils.pyutil as utl

def ConnectAsClientAndGetData(service,msg,EP="tcp://10.66.117.195:55575"):
    context = zmq.Context()
    #  Socket to talk to server
    print("Connecting to get system date")
    socket = context.socket(zmq.REQ)
    socket.connect(EP)
    request = ['FMC-01', service, msg]

    #print("Sending request" , [utl.toBytes(i) for i in request])
    socket.send_multipart([utl.toBytes(i) for i in request])

    #  Get the reply.
    message = socket.recv_multipart()
    message = utl.b2m(message[len(message)-1])

    return message

@method(ProcessRequest,'TestService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - TestService: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    rows = db.Select(queries)
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    return ReplyMsg

#Inserts into TUT Table taking json data of ft's GL_TRANS
@method(ProcessRequest,'TUTService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - TUTService: ')
    rows = getVal(ReplyMsg,"Data",None)
    print("number of rows to insert: " , len(rows))
    headers = " ,".join(list(rows[0].keys()));
    headerPH = ":" + headers.replace(",", ",:")
    coreConn = cx_Oracle.connect("tbapsg/tbapsg@kuchela.ad.infosys.com:1525/fin11bas")
    cursor = coreConn.cursor()
    sql_insert = "insert into TUT_TEST (" +headers + ") values ("+headerPH+")"
    print(sql_insert)
    cursor.executemany(sql_insert, rows, batcherrors=True)
    print("Insert Completed")
    uqs = [x['COLUMN_NAME'] for x in db.Select(cc.GetUC())['0']]
    uqs.extend(['STATUS','ERROR_MESSAGE'])
    print(uqs)
    for i in rows:
        i['STATUS'] = 'SENT'
        i['ERROR_MESSAGE'] = None  
    for errorObj in cursor.getbatcherrors():
        print("Row", errorObj.offset, "has error", errorObj.message)
        rows[errorObj.offset].update({"STATUS":"ERROR"})
        rows[errorObj.offset].update({"ERROR_MESSAGE":errorObj.message})

    res = [{ key:value for key, value in row.items() if key.upper() in uqs } for row in rows] 
    cursor.close()
    coreConn.commit()
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  {'0':res}}}}
    return ReplyMsg

@method(ProcessRequest,'GLService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - GLService: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    print('TIME PRE-DB Select',time.ctime())
    rows = db.Select(queries)
    print('TIME POST-DB Select',time.ctime())
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    return ReplyMsg

@method(ProcessRequest,'GLService1')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - GLService1: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    print('TIME PRE-DB Select',time.ctime())
    rows = db.Select(queries)
    print('TIME POST-DB Select',time.ctime())
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    #('FMW-01-GetSystemDateService' , {'Query': ['select TO_char(get_system_date) getsysdate from dual'], 'Service': 'FMW-01-GetSystemDateService'})
    msg = {'Query':['INSERT_INTO_TUT'],'Service': 'FMW-01-TUTService','Data':rows['0']}
    ReplyMsg =ConnectAsClientAndGetData('FMW-01-TUTService',msg)
    return ReplyMsg


@method(ProcessRequest,'GLService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - GLService: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    print('TIME PRE-DB Select',time.ctime())
    rows = db.Select(queries)
    print('TIME POST-DB Select',time.ctime())
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    return ReplyMsg

@method(ProcessRequest,'RateService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - TestService: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    rows = {'0': [{'USD/INR': '72.50'}]}
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    return ReplyMsg

@method(ProcessRequest,'GetSystemDateService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - GetSystemDateService: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    rows = db.Select(queries)
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    return ReplyMsg

@method(ProcessRequest,'NostroService')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - NostroService: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    rows = db.Select(queries)
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    return ReplyMsg

#fetch the bind variable from another worker as Client
def FetchBind(service,msg):
    context = zmq.Context()
    #  Socket to talk to server
    print("Connecting to get system date")
    socket = context.socket(zmq.REQ)
    socket.connect("tcp://10.66.117.195:55575")
    request = ['FMC-01', service, msg]
    #  Do 10 requests, waiting each time for a response
    print("Sending request" , [utl.toBytes(i) for i in request])
    socket.send_multipart([utl.toBytes(i) for i in request])

    #  Get the reply.
    message = socket.recv_multipart()
    message = utl.b2m(message[len(message)-1])
    print("Received reply :",  message)
    #[b'FMC-01', b'FMW-01-GetSystemDateService', b'{"ProcessName": "GetSystemDateService", "Query": ["select TO_char(get_system_date) getsysdate from dual"], "Service": "FMW-01-GetSystemDateService", "OUTPUT": {"Data": {"0": [{"GETSYSDATE": "20-OCT-25"}]}}}']

    output = message["OUTPUT"]["Data"]["0"][0]
 
    print("OP : " ,output)

    return output 

@method(ProcessRequest,'NostroServiceNoBind')
def ProcessRequest(ReplyMsg):
    print('ProcessRequest - NostroServiceNoBind: ' , ReplyMsg)
    queries = getVal(ReplyMsg,"Query",None)
    if queries[0]['binds'] is None:
        bind = FetchBind('FMW-01-GetSystemDateService' , {'Query': ['select TO_char(get_system_date) getsysdate from dual'], 'Service': 'FMW-01-GetSystemDateService'})
        queries[0]['binds']=bind
    rows = db.Select(queries)
    ReplyMsg = {**ReplyMsg,**{"OUTPUT": {"Data":  rows}}}
    return ReplyMsg


