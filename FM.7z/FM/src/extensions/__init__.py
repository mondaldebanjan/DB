# -*- coding: utf-8 -*-
from extensions.FTQS import *

