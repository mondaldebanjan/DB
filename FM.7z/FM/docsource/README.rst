
FM - for mircroservices 
***********************

FM  infrastructure will serve as a hub that can direct requests and works to different services asynchronously. 
It will also give a framework to easily add new services (in a matter of 2-3 days, instead of weeks) , and can serve well for customizations and ad-hoc services.

One of the main objectives is to separate out the FT core business with adjoining services that are needed in order to fit in an Enterprise architecture. However the design is not restricted to FT , and can be  stand-alone integrating different products and services.

The illustration below gives a basic overview of the FM landscape.

.. figure:: images/FM-Overview.png
   :align: center

FM Broker
=========
FM broker is the hub that orchestrates the Requests and Replies.
All requests come to FM Broker and gets routed to the respective services as given in the message. 
Once the services reply to the broker, it then forwards the reply to the correct client.

All the services(workers) register themselves to the broker once they start up. As soon as the workers start up , they send their message to broker for registry. Also a heartbeat request loop is started that goes on till the worker or broker goes down. This is to keep the ports open even when there are no requests.

.. note::
   Broker has to be started first before any worker or client is started. Broker should be on 
   the same server as the port where the broker is supposed to bind and listen to.

**The following happens once a client request reaches broker:**
    * Broker receives client request.
    * Parses message to find service.
       - Finds service that is needed.
          - If Worker is *free* then sends the request. Marks the worker as *Busy*
          - If Worker is *Busy* then puts the message in the queue. 
            This will get picked up once any of the worker is free.
       - Service not found. Return an error message to the client.
    * Get reply from worker.
       - Send reply to the corresponding client. If more replies are expected then keep worker 
         *busy*. If no more replies are expected then mark worker *free*.

.. note::
   *Currently broker doesn't store the requests or replies in a file or database. Hence in the 
   event of failure or a crash , there would be no way of recovery of the request. The request 
   would have to be replayed.*

FM Worker
=========
FM Worker is designed to do bulk of the heavy lifting and is very easy to customize. 

In fact writing a new service is just a matter of overriding a single function. 
It is not necessary to know the connection type and the reply formats or to load-balance the requests, for someone to write a new micro service.
Hence the time to develop a new service is significantly reduced.

FM Worker is capable of servicing requests asynchronously as well as stream the data to client if needed.
One can have more than one worker for the same service. The requests from the client are distributed to the free workers cyclically.
It is recommanded to have at least 2 workers running for a service that is expected to have more requests or which is expected to take 
a long time to service a request.

Workers are stateless , and expect the requests to be idempotent. This would mean that giving the same request more than once would not
affect the outcome of the result. However , a stateful response can be mimicked if the state itself is passed along with the client request.
This new state information would have to be processed at the worker customization layer.

The following gives a code sample of a custom service written ::

   @method(ProcessRequest,'GLService')   # register the method with your service name.
   def ProcessRequest(ReqMsg):		 # function that is the entry point of requests from client
       """
       Select the queries in the Request and send back async replies in the expected format.
       send the reply as null to mark the end of the response for the request.
       """
       #print('ProcessRequest - GLService ASYNC: ' , ReqMsg)
       queries = getVal(ReqMsg,"Query",None)
	   
       for rows in db.SelectIter(queries,'ASYNC'):
           ret = utl.formReply(rows,more=True)  # formReply formats the reply according to the API. more=True indicates more to come.
           yield ret                            # yield allows for asynchronous reply.
		yield utl.formReply(b'')                    # final reply telling the end of stream of replies. more=False by default

	



   
FTQS *(Finacle Table and Query Service)*
----------------------------------------
Often a client has to request multiple services(db) to do the same kind of work or requests, or different requests but to be done at the same time.
This can be accomplished in parallel by using FTQS. The client contacts FTQS worker with a specified request(s) or a predefined request.
A predefined request is a work item that is defined at the service(FTQS) side and can be invoked with a special command or name.

FTQS is a special Worker. It can run like a normal worker , however it can accept requests from client that want to talk to more than
one service at a time. FTQS would parse through the request and segregate each request for the corresponding client. Then it would arrange
for the requests to be sent to the corresponding services concurrently. It would also recieve replies from multiple services and consolidate
them before sending the whole reply to the requesting client.


The following schematic strives to give a overall picture :

.. figure:: images/FTQS.png
   :align: center



